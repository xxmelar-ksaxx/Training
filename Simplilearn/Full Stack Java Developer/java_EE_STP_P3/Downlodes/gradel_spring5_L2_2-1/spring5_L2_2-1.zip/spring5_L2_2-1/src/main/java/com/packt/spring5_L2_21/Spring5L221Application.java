package com.packt.spring5_L2_21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring5L221Application {

	public static void main(String[] args) {
		SpringApplication.run(Spring5L221Application.class, args);
	}

}
