package com.packt.spring5_L2_21;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring5L221ApplicationTests {

	@Test
	void contextLoads() {
	}

}
